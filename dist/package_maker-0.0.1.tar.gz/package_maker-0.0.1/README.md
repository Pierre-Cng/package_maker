# package_maker
A python package to make python package template

Links used:
* https://docs.pytest.org/en/7.1.x/explanation/goodpractices.html
* https://packaging.python.org/en/latest/tutorials/packaging-projects/
* https://tox.wiki/en/latest/user_guide.html
* https://python-packaging.readthedocs.io/en/latest/minimal.html
* https://setuptools.pypa.io/en/latest/userguide/pyproject_config.html#dynamic-metadata
